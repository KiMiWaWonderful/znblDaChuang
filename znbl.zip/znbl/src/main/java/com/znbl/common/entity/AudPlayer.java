package com.znbl.common.entity;

//观众
public class AudPlayer {

    Integer id;

    Integer u_id;
}
