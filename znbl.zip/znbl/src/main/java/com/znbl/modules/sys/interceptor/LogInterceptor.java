package com.znbl.modules.sys.interceptor;

public class LogInterceptor {
}
