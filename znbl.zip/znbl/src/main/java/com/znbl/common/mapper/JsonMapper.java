package com.znbl.common.mapper;

public class JsonMapper {
}
