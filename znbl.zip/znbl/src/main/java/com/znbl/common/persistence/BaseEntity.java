package com.znbl.common.persistence;

public class BaseEntity {
}
