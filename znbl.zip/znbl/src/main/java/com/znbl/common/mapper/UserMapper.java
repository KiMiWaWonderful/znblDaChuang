package com.znbl.common.mapper;

import com.znbl.common.entity.User;

public interface UserMapper {

    //注册
    public void addUser();

    //登录
    public User getUserById(Integer id);
}
