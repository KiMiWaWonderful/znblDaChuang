package com.example.service;

public interface GPSInformationService {

    //增加
    void addGPSInformation(String gpsInformationJson);
}
