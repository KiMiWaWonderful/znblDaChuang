package com.example.service;

import com.example.pojo.Point;

import java.util.List;

public interface CarLocationService {

     List<Point> getAllLocation();
}
