package com.znbl.common.service;

import com.znbl.common.entity.User;

public interface UserService {

    //注册
    public void register();

    //登录
    public User login(Integer id);
}
